package com.nishant.rest.webservices.restserices.user;

import java.net.URI;
import java.nio.file.attribute.UserPrincipalNotFoundException;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.apache.catalina.connector.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

@RestController
public class UserJPAResource {
	
	@Autowired
	private UserDaoService service;
	
	@Autowired
	private UserRepository userrepository;
	//retrieve all users
	
	@Autowired
	private PostRepository postrepository;
	
	@GetMapping("/jpa/users")
	public List<User> retrieveAllUsers()
	{
		return userrepository.findAll();
	}
	
	@GetMapping("/jpa/users/{id}")
	public Optional<User> retrieveUser(@PathVariable int id)
	{
		Optional<User> user= userrepository.findById(id);
		if (!user.isPresent())
			throw new UserNotFoundException("id-"+id);
		
		//hateoas
		/*Resource<User> resource=new Resource<User>(user);
		
		ControllerLinkBuilder linkTo =linkTo(methodOn(this.getClass()).retrieveAllUsers());
		resource.add(linkTo.withRel("all-users"));
		*/
		return user;
	}
	
	

	private UserJPAResource methodOn(Class<? extends UserJPAResource> class1) {
		// TODO Auto-generated method stub
		return null;
	}

	@DeleteMapping("/jpa/users/{id}")
	public void deleteUser(@PathVariable int id)
	{
		userrepository.deleteById(id);
		
	}
	
	@PostMapping("/jpa/users/{id}/posts")
	public ResponseEntity<Object> createpost(@PathVariable int id,@RequestBody Post post)
		{
			Optional<User> useroptional= userrepository.findById(id);
			if (!useroptional.isPresent())
				throw new UserNotFoundException("id-"+id);
			
				User user = useroptional.get();
				post.setUser(user);
				
				postrepository.save(post);
			
			URI location=ServletUriComponentsBuilder
					.fromCurrentRequest()
					.path("/{id}")
					.buildAndExpand(post.getId()).toUri();
			
			return ResponseEntity.created(location).build();
		}
	
	
	@GetMapping("/jpa/users/{id}/posts")
	public List<Post> retrieveAllUsers(@PathVariable int id)
	{
		Optional<User> useroptional = userrepository.findById(id);
		
		if(!useroptional.isPresent())
		{
			throw new UserNotFoundException("id- "+id);
		}
		return useroptional.get().getPosts();
		
	}
}
