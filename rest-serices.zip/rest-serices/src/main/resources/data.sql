insert into user values(1001,sysdate(),'jack');
insert into user values(2002,sysdate(),'jill');
insert into post values(1002,'My 1st post',1001);
insert into post values(2002,'My 2nd post',1001);
