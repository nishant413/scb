package com.nishant.rest.jpa.springbootjpa;



import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nishant.rest.jpa.springbootjpa.entity.User;
import com.nishant.rest.jpa.springbootjpa.service.UserDAOService;
import com.nishant.rest.jpa.springbootjpa.service.UserRepository;

@Component
public class UserRepositoryCommandlineRunner implements CommandLineRunner{

	private static final Logger log=LoggerFactory.getLogger(UserRepositoryCommandlineRunner.class);
	
	@Autowired
	private UserRepository userrepository;
	
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		User user=new User("Jill","Admin");
		userrepository.save(user);
		Optional<User> useridone = userrepository.findById(1L);
		log.info("New user is retrieved: "+useridone);

		
		List<User> users = userrepository.findAll();
		log.info("All users retrieved: "+users);
		
		
	}
	
}
