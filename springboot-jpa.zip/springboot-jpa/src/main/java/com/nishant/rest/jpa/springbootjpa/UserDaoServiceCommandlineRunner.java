package com.nishant.rest.jpa.springbootjpa;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nishant.rest.jpa.springbootjpa.entity.User;
import com.nishant.rest.jpa.springbootjpa.service.UserDAOService;

@Component
public class UserDaoServiceCommandlineRunner implements CommandLineRunner{

	private static final Logger log=LoggerFactory.getLogger(UserDaoServiceCommandlineRunner.class);
	
	@Autowired
	private UserDAOService userdaoservice;
	
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		User user=new User("Jack","Admin");
		long id = userdaoservice.insert(user);
		log.info("New user is created: "+user);
		
	}
	
}
