package com.nishant.rest.jpa.springbootjpa.service;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nishant.rest.jpa.springbootjpa.entity.User;

public interface UserRepository extends JpaRepository<User,Long>{
	
	
}
