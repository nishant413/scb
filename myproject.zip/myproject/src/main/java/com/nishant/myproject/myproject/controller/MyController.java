package com.nishant.myproject.myproject.controller;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.nishant.myproject.myproject.dao.MyDao;
import com.nishant.myproject.myproject.entity.User;
import com.nishant.myproject.myproject.service.MyService;



@RestController
public class MyController {

	@Autowired 
	private MyService service;
	@Autowired
	private MyDao dao;
	
	@RequestMapping("/welcome")
	public ModelAndView firstPage() {
		return new ModelAndView("welcome");
	}
	
	
	@RequestMapping(value="/signup",method = RequestMethod.POST)
	public Object Signup(@ModelAttribute("user") User details) 
	{
		return service.signup(details);
		
	}
	
	
	
	
	
	 @RequestMapping(value = "/login", method = RequestMethod.POST)
	  public ModelAndView loginProcess(HttpServletRequest request, HttpServletResponse response,
	  @ModelAttribute("login") User login) {
	    ModelAndView mav = null;
	    User user = dao.validateUser(login);
	    if (null != user) {
	    mav = new ModelAndView("welcome");
	    mav.addObject("firstname", user.getUsername());
	    } else {
	    mav = new ModelAndView("login");
	    mav.addObject("message", "Username or Password is wrong!!");
	    }
	    return mav;
	  }

	
	
	
	
	

}
