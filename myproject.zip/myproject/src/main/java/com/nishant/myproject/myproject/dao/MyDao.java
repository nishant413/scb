package com.nishant.myproject.myproject.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nishant.myproject.myproject.entity.User;

@Transactional
@Repository
public class MyDao {

	  @Autowired
	  JdbcTemplate jdbcTemplate;


	public User validateUser(User details) {
	    String sql = "select * from scb_training where email='" + details.getEmail() + "' and password='" + details.getPassword()
	    + "'";
	    List<User> users = jdbcTemplate.query(sql, new UserMapper());
	    return users.size() > 0 ? users.get(0) : null;
	    }


}
