package com.nishant.myproject.myproject.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;

import com.nishant.myproject.myproject.entity.User;

public class UserMapper implements RowMapper<User> {

	public User mapRow(ResultSet rs, int arg1) throws SQLException {
	    User user = new User();
	    user.setUsername(rs.getString("username"));
	    user.setId(rs.getLong("id"));
	    user.setEmail(rs.getString("email"));
	    user.setDob(rs.getDate("dob"));
	    user.setCompany(rs.getString("company"));
	    user.setPassword(rs.getString("password"));
	    user.setCity(rs.getString("city"));
	    
	    
	    return user;
	  }

}
