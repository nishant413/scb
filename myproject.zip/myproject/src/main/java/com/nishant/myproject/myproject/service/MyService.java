package com.nishant.myproject.myproject.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nishant.myproject.myproject.dao.MyDao;
import com.nishant.myproject.myproject.entity.User;
import com.nishant.myproject.myproject.postrepository.PostRepoitory;

@Service
public class MyService {

	@Autowired PostRepoitory jpa;

	public Object signup(User details)
	{
		return jpa.save(details);
	
	}
	
	




}
