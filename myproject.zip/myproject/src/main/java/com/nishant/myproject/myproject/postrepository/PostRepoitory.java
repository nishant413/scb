package com.nishant.myproject.myproject.postrepository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.nishant.myproject.myproject.entity.User;

public interface PostRepoitory extends JpaRepository<User,Long>{

	 
	

}
