import java.sql.*;
import java.sql.DriverManager;
import java.util.Scanner;

public class Jdbc_Connection {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@hklpdudasb-scan.hk.standardchartered.com:1622/CDMS_DEV_01.hk.standardchartered.com", "CDMS_DEV_01", "CDMS_DEV_01_123");
			
			// statetment
		/*	Statement stmt=con.createStatement();
			ResultSet sql=stmt.executeQuery("select ID_OBJ,X_MY_LATEST_TXN_ID,X_LATEST_TXN_ID,X_REF_ID from SCB_MASTER where x_ref_id in (\'1000647550\')");
			while(sql.next())
			{
				System.out.println(sql.getLong(1)+" "+sql.getString(2)+" "+sql.getString(3)+" "+sql.getString(4)+" ");
			} 
			*/
			
			
			
			
		//prepared statement
			PreparedStatement smt=con.prepareStatement("select ID_OBJ,X_MY_LATEST_TXN_ID,X_LATEST_TXN_ID,X_REF_ID from SCB_MASTER where x_ref_id=\'1000605277\'");
			ResultSet sqlp=smt.executeQuery();
			while(sqlp.next())
			{
				
				System.out.println(sqlp.getLong(1)+" "+sqlp.getString(2)+" "+sqlp.getString(3)+" "+sqlp.getString(4)+" ");
			
			}
		
			/*System.out.println("Enter the id");
			int id=sc.nextInt();
			System.out.println("Enter the name");
			String name=sc.next();
			
			Statement ins=con.createStatement();
			ResultSet sql=ins.executeQuery("insert into SCB_train values('"+id+"','"+name+"')");
			*/
			
			
			/*
			PreparedStatement updt=con.prepareStatement("insert into SCB_train values(?,?)");
			updt.setInt(1,id);
			updt.setString(2,name);
			int i=updt.executeUpdate();
			
			System.out.println(i+"Records Updated");
		
			CallableStatement clble=con.prepareCall("{call insertR(?,?)}");
			clble.setInt(1,id);
			clble.setString(2, name);
			
			clble.executeQuery();
			System.out.println("Inserted....");
			*/
			con.close();
			
		}
		catch(Exception e)
		{ 
			System.out.println(e);
		}  
	}
}
