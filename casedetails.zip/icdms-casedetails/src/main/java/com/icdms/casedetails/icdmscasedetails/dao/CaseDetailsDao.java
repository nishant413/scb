package com.icdms.casedetails.icdmscasedetails.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.icdms.casedetails.icdmscasedetails.entity.CaseDetails;


@Transactional
@Repository
public class CaseDetailsDao {
	
	@Autowired
	public JdbcTemplate jdbctemplate;
	
	@Autowired
	public Environment env;
	
	public List<CaseDetails> getJdbcDetails()
	{
		String sql="select * from  scb_train";
		RowMapper<CaseDetails> rowMapper = new CaseRowMapper();
		return this.jdbctemplate.query(sql, rowMapper);
		
	}
	
	public Object insertJdbc(CaseDetails obj)
	{
		String sql="insert into scb_train values(?,?,?,?,?,?,?,?,?,?)";
		return jdbctemplate.update(sql,obj.getAgreement_Date(),obj.getScb_country(),obj.getDocumentation_location(),obj.getDocument_category(),obj.getDocument_type(),obj.getDocument_name(),obj.getDocument_priority(),obj.getAdditional_number(),obj.getLegal_entity_name(),obj.getSci_legal_entity_id());
	}
	
	public List<CaseDetails> getAllQuery()
	{
		String sql=env.getProperty("icdms.query.select.all");
		RowMapper<CaseDetails> rowMapper = new CaseRowMapper();
		return jdbctemplate.query(sql, rowMapper);
	}
}
