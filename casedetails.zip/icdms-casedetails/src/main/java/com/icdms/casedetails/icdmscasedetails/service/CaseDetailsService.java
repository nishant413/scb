package com.icdms.casedetails.icdmscasedetails.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icdms.casedetails.icdmscasedetails.dao.CaseDetailsDao;
import com.icdms.casedetails.icdmscasedetails.entity.CaseDetails;
import com.icdms.casedetails.icdmscasedetails.repository.PostRepository;


@Service
public class CaseDetailsService {

	@Autowired
	private PostRepository postrepository;
	
	@Autowired
	private CaseDetailsDao dao;
	
	
	public CaseDetails insertJpa(CaseDetails details) 
	{
		return postrepository.save(details);
	}
	
	public List<CaseDetails> getJpaDetails()
	{
		
		return postrepository.findAll();
		
	}
	
	public List<CaseDetails> getJdbcDetails()
	{
		return dao.getJdbcDetails();
	}

	public Object insertJdbc(CaseDetails details) {
		
		return dao.insertJdbc(details);
		
	}

	public List<CaseDetails> getAllQuery() {
		return dao.getAllQuery();
	}
}
