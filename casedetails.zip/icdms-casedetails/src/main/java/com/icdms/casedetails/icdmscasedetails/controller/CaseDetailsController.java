package com.icdms.casedetails.icdmscasedetails.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.icdms.casedetails.icdmscasedetails.entity.CaseDetails;
import com.icdms.casedetails.icdmscasedetails.service.CaseDetailsService;

@RestController
public class CaseDetailsController {

	@Autowired
	private CaseDetailsService service;
	
	@PostMapping("icdms/postjpacasedetails")
	public Object insertjpa(@RequestBody CaseDetails details)
	{
		
		return service.insertJpa(details);
		
	}
	
	@GetMapping("icdms/getjpadetails")
	public List<CaseDetails> getJpaDetails()
	{
		return service.getJpaDetails();
	}
	
	@GetMapping("icdms/getjdbcdetails")
	public List<CaseDetails> getJdbcDetails()
	{
		return service.getJdbcDetails();
	}
	
	@PostMapping("icdms/postjdbcdetails")
	public Object insertjdbc(@RequestBody CaseDetails details)
	{
		return service.insertJdbc(details);
	}
	
	
	@GetMapping("icdms/querygetall")
	public List<CaseDetails> getAllQuery()
	{
		return service.getAllQuery();
	}
	
}
