package com.restapai.icdms.training.icdmsapiservicephase1.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.restapai.icdms.training.icdmsapiservicephase1.entity.SCB;
import com.restapai.icdms.training.icdmsapiservicephase1.entity.ScbRowMapper;

@Transactional
@Repository
public class ScbDao {
	
	@Autowired
	private JdbcTemplate jdbctemplate;
	
	public SCB getdetails()
	{
		String sql="select ID_OBJ,X_MY_LATEST_TXN_ID,X_LATEST_TXN_ID,X_REF_ID from SCB_MASTER where x_ref_id=\'2000006070\'";
		RowMapper<SCB> rowMapper = new BeanPropertyRowMapper<SCB>(SCB.class);
		SCB scb = jdbctemplate.queryForObject(sql, rowMapper);
		return scb;
		
	}
	
	public List<SCB> getAllDetails() {
		String sql="select ID_OBJ,X_MY_LATEST_TXN_ID,X_LATEST_TXN_ID,X_REF_ID from SCB_MASTER where ID_OBJ<=\'20130316100000094\'";
        //RowMapper<Article> rowMapper = new BeanPropertyRowMapper<Article>(Article.class);
		RowMapper<SCB> rowMapper = new ScbRowMapper();
		return this.jdbctemplate.query(sql, rowMapper);
	}

	public SCB getIdDetails(long id) {
		// TODO Auto-generated method stub
		String sql="select ID_OBJ,X_MY_LATEST_TXN_ID,X_LATEST_TXN_ID,X_REF_ID from SCB_MASTER where ID_OBJ=? ";
		RowMapper<SCB> rowMapper = new ScbRowMapper();
		SCB scb = jdbctemplate.queryForObject(sql, rowMapper,id);
		return scb;
	}	
	
	
	
}
