package com.restapai.icdms.training.icdmsapiservicephase1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.restapai.icdms.training.icdmsapiservicephase1.dao.ScbDao;
import com.restapai.icdms.training.icdmsapiservicephase1.entity.SCB;

@Service
public class ScbService {
	@Autowired
	private ScbDao scbdao;
	
	public SCB getdetails()
	{
		SCB scb=scbdao.getdetails();
		return scb;
	}
	
	public List<SCB> getAllDetails(){
		return scbdao.getAllDetails();
	}

	public SCB getIdDetails(long id) {
		// TODO Auto-generated method stub
		return scbdao.getIdDetails(id);
		
	}
}
