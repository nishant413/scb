package com.restapai.icdms.training.icdmsapiservicephase1.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.restapai.icdms.training.icdmsapiservicephase1.entity.SCB;
import com.restapai.icdms.training.icdmsapiservicephase1.service.ScbService;

@RestController
public class ScbController {
	
	@Autowired
	private ScbService service;
	
	
	@GetMapping(path="icdms/v1")
	public ResponseEntity<SCB> getdetails()
	{
		SCB scb=service.getdetails();
		return new ResponseEntity<SCB>(scb,HttpStatus.OK);
		
	}
	
	
	@GetMapping(path="icdms/all")
	public ResponseEntity<List<SCB>> getAllDetails() {
		List<SCB> list = service.getAllDetails();
		return new ResponseEntity<List<SCB>>(list, HttpStatus.OK);
	}
	
	@GetMapping("icdms/v1/{id}")
	public SCB getIdDetails(@PathVariable long id) {
		SCB scb=service.getIdDetails(id);
		return scb;
		
	}
}
