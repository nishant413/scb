package com.restapai.icdms.training.icdmsapiservicephase1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IcdmsApiServicePhase1Application {

	public static void main(String[] args) {
		SpringApplication.run(IcdmsApiServicePhase1Application.class, args);
	}
}
