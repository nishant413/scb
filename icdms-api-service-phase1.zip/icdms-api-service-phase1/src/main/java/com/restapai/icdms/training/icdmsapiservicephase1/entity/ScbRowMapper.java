package com.restapai.icdms.training.icdmsapiservicephase1.entity;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class ScbRowMapper implements RowMapper<SCB>{
	
	@Override
	public SCB mapRow(ResultSet row, int rowNum) throws SQLException {
		SCB scb = new SCB();
		scb.setId_obj(row.getLong("ID_OBJ"));
		scb.setX_LATEST_TXN_ID(row.getString("X_MY_LATEST_TXN_ID"));
		scb.setX_LATEST_TXN_ID(row.getString("X_LATEST_TXN_ID"));
		scb.setX_REF_ID(row.getString("X_REF_ID"));
		
		return scb;
	}
}
