package com.nishant.soap.webservices.soapwebservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoapWebservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoapWebservicesApplication.class, args);
	}
}
