package com.nishant.soap.webservices.soapwebservices.soap;

import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.nishant.courses.CourseDetails;
import com.nishant.courses.GetCourseDetailsRequest;
import com.nishant.courses.GetCourseDetailsResponse;

@Endpoint
public class CourseDetailsEndpoint {
	
	//method
	//input-request
	//output-response
	
	
	@PayloadRoot(namespace="http://nishant.com/courses",localPart="GetCourseDetailsRequest")
	@ResponsePayload
	public GetCourseDetailsResponse
	processCourseDetailsRequest(@RequestPayload GetCourseDetailsRequest request)
	{
		GetCourseDetailsResponse response=new GetCourseDetailsResponse();
		CourseDetails coursedetails=new CourseDetails();
		coursedetails.setId(request.getId());
		coursedetails.setName("Rest-api");
		coursedetails.setDescription("Spring-boot with java");
		
		return response;
	}
}
