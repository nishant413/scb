package com.icdms.api.jpa.icdmsapijpa.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icdms.api.jpa.icdmsapijpa.entity.SCB;
import com.icdms.api.jpa.icdmsapijpa.entity.Scb_train;
import com.icdms.api.jpa.icdmsapijpa.repository.ScbPostRepository;
import com.icdms.api.jpa.icdmsapijpa.repository.ScbRepository;
import com.icdms.api.jpa.icdmsapijpa.service.exception.UserNotFoundException;


@Service
public class ScbService {
	
	@Autowired
	private ScbRepository repository;
	
	@Autowired
	private ScbPostRepository postrepository;
	
	public Optional<SCB> getIdDetails(long id){
		
		 Optional<SCB> user = repository.findById(id);
		 if (!user.isPresent())
		 {
			 throw new UserNotFoundException("id is-"+id);
		 }
		 return user;
	}

	public List<SCB> getAllDetails() {
		return repository.getAllDetails();
	}

	public Scb_train adduser(@Valid Scb_train details) {
	
		
		return postrepository.save(details);
		
	}

	
}
