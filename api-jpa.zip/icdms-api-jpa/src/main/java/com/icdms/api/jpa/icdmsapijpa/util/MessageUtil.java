package com.icdms.api.jpa.icdmsapijpa.util;

public class MessageUtil {

	private static volatile StatusMessage statusMessage = null;

	private MessageUtil() {
	}

	public static StatusMessage getStatusMessage() {
		if (statusMessage == null) {
			synchronized (StatusMessage.class) {
				if (statusMessage == null) {
					statusMessage = new StatusMessage();
				}
			}
		}
		return statusMessage;
	}
}
