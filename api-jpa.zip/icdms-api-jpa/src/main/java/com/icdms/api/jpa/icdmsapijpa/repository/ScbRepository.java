package com.icdms.api.jpa.icdmsapijpa.repository;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


import com.icdms.api.jpa.icdmsapijpa.entity.SCB;



public interface ScbRepository extends JpaRepository<SCB, Long>{
	
	
	
	@Query(value="select id_obj,X_MY_LATEST_TXN_ID,X_LATEST_TXN_ID,X_REF_ID "+"FROM SCB  WHERE X_REF_ID=\'2000006070\' ")
    public List<SCB> getAllDetails();
}
