package com.icdms.api.jpa.icdmsapijpa.controller;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.icdms.api.jpa.icdmsapijpa.entity.SCB;
import com.icdms.api.jpa.icdmsapijpa.entity.Scb_train;
import com.icdms.api.jpa.icdmsapijpa.service.ScbService;
import com.icdms.api.jpa.icdmsapijpa.util.MessageUtil;
import com.icdms.api.jpa.icdmsapijpa.util.StatusMessage;


@RestController
@PropertySource("classpath:messages.properties")
public class ScbController {
	 @Autowired
	 private ScbService service;
	 
	 @Autowired
	 private Environment env;
	 
	 private final static Logger log = Logger
				.getLogger(ScbController.class);
	
	 @GetMapping("/icdms/{id}")
	 public Object getIdDetails(@PathVariable long id)
	 {
		 Object obj=null;
		 try {
		  obj = service.getIdDetails(id);
			 return obj;
		 }
		 catch(Exception e)
		 {
			 
			 log.error(e.getMessage());
				StatusMessage stsMsg = MessageUtil.getStatusMessage();
				stsMsg.setStatus(env.getProperty("icdms.error.idnotfound"));
				return stsMsg;
		 }
	
		 
	 }
	 
	 @GetMapping("/icdms/all")
	 public List<SCB> getAllDetails()
	 {
		 List<SCB> list=service.getAllDetails();
		return list;
		 
	 }
	 @PostMapping("/icdms/post")
	 public ResponseEntity<Object> adduser(@Valid @RequestBody Scb_train details)
	 {
		
		 
		 Scb_train saveduser=service.adduser(details);
		
		URI location=ServletUriComponentsBuilder
				.fromCurrentRequest()
				.path("/{id}")
				.buildAndExpand(saveduser.getId()).toUri();
		
		return ResponseEntity.created(location).build();
		
		
	 }
	 
	 
}
