package com.icdms.api.jpa.icdmsapijpa.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name ="SCB_MASTER")
public class SCB {
	
	@Id
	@Column(name="id_obj")
	private long id_obj;
	
	@Column(name="X_MY_LATEST_TXN_ID")
	private String X_MY_LATEST_TXN_ID;
	
	@Column(name="X_LATEST_TXN_ID")
	private String X_LATEST_TXN_ID;
	
	@Column(name="X_REF_ID")
	private String X_REF_ID ;

	public long getId_obj() {
		return id_obj;
	}

	public void setId_obj(long id_obj) {
		this.id_obj = id_obj;
	}

	public String getX_MY_LATEST_TXN_ID() {
		return X_MY_LATEST_TXN_ID;
	}

	public void setX_MY_LATEST_TXN_ID(String x_MY_LATEST_TXN_ID) {
		X_MY_LATEST_TXN_ID = x_MY_LATEST_TXN_ID;
	}

	public String getX_LATEST_TXN_ID() {
		return X_LATEST_TXN_ID;
	}

	public void setX_LATEST_TXN_ID(String x_LATEST_TXN_ID) {
		X_LATEST_TXN_ID = x_LATEST_TXN_ID;
	}

	public String getX_REF_ID() {
		return X_REF_ID;
	}

	public void setX_REF_ID(String x_REF_ID) {
		X_REF_ID = x_REF_ID;
	}
	
}
