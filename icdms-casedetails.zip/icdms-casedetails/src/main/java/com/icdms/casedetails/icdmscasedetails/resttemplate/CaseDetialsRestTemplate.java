package com.icdms.casedetails.icdmscasedetails.resttemplate;

import java.sql.Date;

import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.icdms.casedetails.icdmscasedetails.entity.CaseDetails;

public class CaseDetialsRestTemplate {
 public static void main(String[] args) {
	 RestTemplate resttemplate = new RestTemplate();

	 
	 //post using resttemplate
		
	/*	Date date=new Date(2013/1/1);
		CaseDetails a = new CaseDetails(date,"malaysia","kulalampur","category",
				  "type","gautam","medium",123,"gopal",212312); 
	
	 
	        // Data attached to the request.
	        HttpEntity<CaseDetails> requestBody = new HttpEntity<>(a);
	 System.out.println("_________________printing-----1_______________");
	        // Send request with POST method.
	        ResponseEntity<CaseDetails> result 
	             = resttemplate.postForEntity("http://localhost:8080/icdms/postjdbcdetails", requestBody, CaseDetails.class);
	        System.out.println("_________________printing-----2_______________");
	        System.out.println("Status code:" + result.getStatusCode());*/
	 
	    //get using resttemplate
	/*	
		String list = resttemplate.getForObject("http://localhost:8080/icdms/getjpadetails", String.class);
		System.out.println("---->"+list);
		
		*/
		
		
	}

}
