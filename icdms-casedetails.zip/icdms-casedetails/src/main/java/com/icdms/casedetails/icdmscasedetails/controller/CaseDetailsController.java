package com.icdms.casedetails.icdmscasedetails.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.icdms.casedetails.icdmscasedetails.entity.CaseDetails;
import com.icdms.casedetails.icdmscasedetails.service.CaseDetailsService;

@RestController
public class CaseDetailsController {

	@Autowired
	private CaseDetailsService service;
	
	/*@RequestMapping(value="icdms/post" ,method = RequestMethod.POST)*/
	@RequestMapping(value="/icdms", method = RequestMethod.POST)
	public ModelAndView hello(@ModelAttribute("emp") CaseDetails details)
	{	
		service.insertJpa(details);
		return new ModelAndView("hello");
    }
	
	
	@PostMapping("icdms/postjpacasedetails")
	public Object insertjpa(@RequestBody CaseDetails details)
	{
		
		return service.insertJpa(details);
		
	}
	
	@GetMapping("icdms/getjpadetails")
	public List<CaseDetails> getJpaDetails()
	{
		return service.getJpaDetails();
	}
	
	@GetMapping("icdms/getjdbcdetails")
	public List<CaseDetails> getJdbcDetails()
	{
		return service.getJdbcDetails();
	}
	
	@PostMapping("icdms/postjdbcdetails")
	public Object insertjdbc(@RequestBody CaseDetails details)
	{
		return service.insertJdbc(details);
	}
	
	
	@GetMapping("icdms/querygetall")
	public List<CaseDetails> getAllQuery()
	{
		return service.getAllQuery();
	}
	
}
