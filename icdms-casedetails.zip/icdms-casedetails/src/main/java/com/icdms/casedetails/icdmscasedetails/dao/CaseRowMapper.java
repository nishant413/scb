package com.icdms.casedetails.icdmscasedetails.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.icdms.casedetails.icdmscasedetails.entity.CaseDetails;


public class CaseRowMapper implements RowMapper<CaseDetails>
{
	@Override
	public CaseDetails mapRow(ResultSet row, int rowNum) throws SQLException
	{
		CaseDetails obj=new CaseDetails();
		obj.setAgreement_Date(row.getDate("Agreement_Date"));
		obj.setScb_country(row.getString("scb_country"));
		obj.setDocumentation_location(row.getString("documentation_location"));
		obj.setDocument_category(row.getString("document_category"));
		obj.setDocument_type(row.getString("document_type"));
		obj.setDocument_name(row.getString("document_name"));
		obj.setDocument_priority(row.getString("document_priority"));
		obj.setAdditional_number(row.getLong("additional_number"));
		obj.setLegal_entity_name(row.getString("legal_entity_name"));
		obj.setSci_legal_entity_id(row.getLong("sci_legal_entity_id"));
		
		return obj;
	} 
	
}
