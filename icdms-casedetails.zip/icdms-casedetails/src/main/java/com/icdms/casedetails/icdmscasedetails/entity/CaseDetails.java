package com.icdms.casedetails.icdmscasedetails.entity;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="scb_train")

public class CaseDetails {
	private Date Agreement_Date;
	private String scb_country;
	private String documentation_location;
	private String document_category;
	private String document_type;
	private String document_name;
	private String document_priority;
	private long additional_number;
	private String legal_entity_name;
	@Id
	private long sci_legal_entity_id;
	public Date getAgreement_Date() {
		return Agreement_Date;
	}
	public void setAgreement_Date(Date agreement_Date) {
		Agreement_Date = agreement_Date;
	}
	public String getScb_country() {
		return scb_country;
	}
	public void setScb_country(String scb_country) {
		this.scb_country = scb_country;
	}
	public String getDocumentation_location() {
		return documentation_location;
	}
	public void setDocumentation_location(String documentation_location) {
		this.documentation_location = documentation_location;
	}
	public String getDocument_category() {
		return document_category;
	}
	public void setDocument_category(String document_category) {
		this.document_category = document_category;
	}
	public String getDocument_type() {
		return document_type;
	}
	public void setDocument_type(String document_type) {
		this.document_type = document_type;
	}
	public String getDocument_name() {
		return document_name;
	}
	public void setDocument_name(String document_name) {
		this.document_name = document_name;
	}
	public String getDocument_priority() {
		return document_priority;
	}
	public void setDocument_priority(String document_priority) {
		this.document_priority = document_priority;
	}
	public long getAdditional_number() {
		return additional_number;
	}
	public void setAdditional_number(long additional_number) {
		this.additional_number = additional_number;
	}
	public String getLegal_entity_name() {
		return legal_entity_name;
	}
	public void setLegal_entity_name(String legal_entity_name) {
		this.legal_entity_name = legal_entity_name;
	}
	public long getSci_legal_entity_id() {
		return sci_legal_entity_id;
	}
	public void setSci_legal_entity_id(long sci_legal_entity_id) {
		this.sci_legal_entity_id = sci_legal_entity_id;
	}
	public CaseDetails(Date agreement_Date, String scb_country, String documentation_location, String document_category,
			String document_type, String document_name, String document_priority, long additional_number,
			String legal_entity_name, long sci_legal_entity_id) {
		super();
		Agreement_Date = agreement_Date;
		this.scb_country = scb_country;
		this.documentation_location = documentation_location;
		this.document_category = document_category;
		this.document_type = document_type;
		this.document_name = document_name;
		this.document_priority = document_priority;
		this.additional_number = additional_number;
		this.legal_entity_name = legal_entity_name;
		this.sci_legal_entity_id = sci_legal_entity_id;
	}

	public CaseDetails() {
		// TODO Auto-generated constructor stub
	}
	public CaseDetails(String string, String scb_country2, String documentation_location2, String document_category2,
			String document_type2, String document_name2, String document_priority2, int additional_number2,
			String legal_entity_name2, int sci_legal_entity_id2) {
		// TODO Auto-generated constructor stub
	}


	
	

	
}
