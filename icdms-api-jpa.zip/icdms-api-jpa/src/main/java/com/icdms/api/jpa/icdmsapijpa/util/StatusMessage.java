package com.icdms.api.jpa.icdmsapijpa.util;

public class StatusMessage {
	private String status;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}
