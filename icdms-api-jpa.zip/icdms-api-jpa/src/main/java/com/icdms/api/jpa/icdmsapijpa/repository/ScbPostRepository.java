package com.icdms.api.jpa.icdmsapijpa.repository;

import org.springframework.stereotype.Repository;

import com.icdms.api.jpa.icdmsapijpa.entity.Scb_train;

import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface ScbPostRepository extends JpaRepository<Scb_train,Integer>{

}
